﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Prison_Project.PrisonersDbFC
{
    class PrisonerDBClass
    {
        public int PrisonerID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DOB { get; set; }
        public string Gender { get; set; }
        public string Country { get; set; }
        public string Height { get; set; }
        public string Weight { get; set; }
        public string Colour { get; set; }
        public string Disease { get; set; }
        public string MaritalStatus { get; set; }
        public string Crime { get; set; } 
        public string DateOfCrime { get; set; }
        public string ImprisonmentDate { get; set; }
        public string ReleaseDate { get; set; }
        public string PrisonCell { get; set; }
        public string Visitors { get; set; }
        public string ExtraInfo { get; set; }

        static string strConnection = ConfigurationManager.ConnectionStrings["Prison_Project.Properties.Settings.PrisonDBConnectionString"].ConnectionString;

        public DataTable SelectPrisoners()
        {
            SqlConnection conn = new SqlConnection(strConnection);

            //Create an Object for DataTable
            DataTable DT = new DataTable();
            try
            {
                // Step 2: Write Sql Query
                string querySelAll = "SELECT * FROM Prisoners";
                // Create Command using "sql" and "conn"
                SqlCommand cmd = new SqlCommand(querySelAll, conn);
                // Create SqlDataAdapter using cmd
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                // Open connection
                conn.Open();
                // Fill our dt with our adapter.
                adapter.Fill(DT);
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return DT;
        }

        public bool InsertPrisoners(PrisonerDBClass pdbc)
        {
            // Creating a default return type and setting its value to false
            bool isSuccess = false;

            // Step 1: Database Connection
            SqlConnection conn = new SqlConnection(strConnection);

            try
            {
                // Step 2: Write Sql Query to insert data
                string queryInsert = "INSERT INTO Prisoners(FirstName, LastName, DOB, Gender, Country, Height, Weight, Colour, Disease, MaritalStatus, Crime, DateOfCrime, ImprisonmentDate, ReleaseDate, PrisonCell, Visitors, ExtraInfo) VALUES (@FirstName, @LastName, @DOB, @Gender, @Country, @Height, @Weight, @Colour, @Disease, @MaritalStatus, @Crime, @DateOfCrime, @ImprisonmentDate, @ReleaseDate, @PrisonCell, @Visitors, @ExtraInfo)";

                // Create cmd using "sql" and "conn"
                SqlCommand cmd = new SqlCommand(queryInsert, conn);

                // Create Parameters to add data
                cmd.Parameters.AddWithValue("@FirstName", pdbc.FirstName);
                cmd.Parameters.AddWithValue("@LastName", pdbc.LastName);
                cmd.Parameters.AddWithValue("@DOB", pdbc.DOB);
                cmd.Parameters.AddWithValue("@Gender", pdbc.Gender);
                cmd.Parameters.AddWithValue("@Country", pdbc.Country);
                cmd.Parameters.AddWithValue("@Height", pdbc.Height);
                cmd.Parameters.AddWithValue("@Weight", pdbc.Weight);
                cmd.Parameters.AddWithValue("@Colour", pdbc.Colour);
                cmd.Parameters.AddWithValue("@Disease", pdbc.Disease);
                cmd.Parameters.AddWithValue("@MaritalStatus", pdbc.MaritalStatus);
                cmd.Parameters.AddWithValue("@Crime", pdbc.Crime);
                cmd.Parameters.AddWithValue("@DateOfCrime", pdbc.DateOfCrime);
                cmd.Parameters.AddWithValue("@ImprisonmentDate", pdbc.ImprisonmentDate);
                cmd.Parameters.AddWithValue("@ReleaseDate", pdbc.ReleaseDate);
                cmd.Parameters.AddWithValue("@PrisonCell", pdbc.PrisonCell);
                cmd.Parameters.AddWithValue("@Visitors", pdbc.Visitors);
                cmd.Parameters.AddWithValue("@ExtraInfo", pdbc.ExtraInfo);

                // Open connection
                conn.Open();

                // Run the Query
                int rows = cmd.ExecuteNonQuery();

                // If the query runs successfully then the value "rows" will be greater then zero else it will be zero
                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }

        public bool UpdatePrisoner(PrisonerDBClass pdbc)
        {
            SqlConnection conn = new SqlConnection(strConnection);

            bool isSuccess = false;

            try
            {
                string queryUpdate = "UPDATE Prisoners SET FirstName = @Firstname, LastName = @LastName, DOB = @DOB, Gender = @Gender, Country = @Country, Height = @Height, Weight = @Weight, Colour = @Colour, Disease = @Disease, MaritalStatus = @MaritalStatus, Crime = @Crime, DateOfCrime = @DateOfCrime, ImprisonmentDate = @ImprisonmentDate, ReleaseDate = @ReleaseDate, PrisonCell = @PrisonCell, Visitors = @Visitors, ExtraInfo = @ExtraInfo WHERE PrisonerID = @PrisonerID";
                SqlCommand cmd = new SqlCommand(queryUpdate, conn);

                cmd.Parameters.Add("@FirstName", pdbc.FirstName);
                cmd.Parameters.Add("@LastName", pdbc.LastName);
                cmd.Parameters.Add("@DOB", pdbc.DOB);
                cmd.Parameters.Add("@Gender", pdbc.Gender);
                cmd.Parameters.Add("@Country", pdbc.Country);
                cmd.Parameters.Add("@Height", pdbc.Height);
                cmd.Parameters.Add("@Weight", pdbc.Weight);
                cmd.Parameters.Add("@Colour", pdbc.Colour);
                cmd.Parameters.Add("@Disease", pdbc.Disease);
                cmd.Parameters.Add("@MaritalStatus", pdbc.MaritalStatus);
                cmd.Parameters.Add("@Crime", pdbc.Crime);
                cmd.Parameters.Add("@DateOfCrime", pdbc.DateOfCrime);
                cmd.Parameters.Add("@ImprisonmentDate", pdbc.ImprisonmentDate);
                cmd.Parameters.Add("@ReleaseDate", pdbc.ReleaseDate);
                cmd.Parameters.Add("@PrisonCell", pdbc.PrisonCell);
                cmd.Parameters.Add("@Visitors", pdbc.Visitors);
                cmd.Parameters.Add("@ExtraInfo", pdbc.ExtraInfo);
                cmd.Parameters.Add("@PrisonerID", pdbc.PrisonerID);

                conn.Open();

                // If the query runs successfully then the value "rows" will be greater then zero else it will be zero
                if (cmd.ExecuteNonQuery() > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }

        public bool DeletePrısoners(PrisonerDBClass pdbc)
        {
            // Creating a default return type and setting its value to false
            bool isSuccess = false;
            // Step 1: Database Connection
            SqlConnection conn = new SqlConnection(strConnection);
            try
            {
                // Step 2: Write Sql Query to Delete data in DB
                string queryDelete = "DELETE FROM Prisoners WHERE PrisonerID = @PrisonerID ";

                // Create Command using "sql" and "conn"
                SqlCommand cmd = new SqlCommand(queryDelete, conn);

                // Create Parameter to delete data
                cmd.Parameters.Add("@PrisonerID", pdbc.PrisonerID);


                // Open connection
                conn.Open();

                // If the query runs successfully then the value "rows" will be greater then zero else it will be zero
                if (cmd.ExecuteNonQuery() > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }
    }
}
