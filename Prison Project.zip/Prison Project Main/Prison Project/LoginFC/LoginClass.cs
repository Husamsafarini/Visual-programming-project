﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Prison_Project.LoginFC
{
    class LoginClass
    {
        public string Email { get; set; }
        public string Password { get; set; }

        static string strConnection = ConfigurationManager.ConnectionStrings["Prison_Project.Properties.Settings.PrisonDBConnectionString"].ConnectionString;

        public bool LoginOfficer(LoginClass lc)
        {
            SqlConnection conn = new SqlConnection(strConnection);

            // Creating a default return type and setting its value to false
            bool isSuccess = false;

            try
            {
                conn.Open();
                string querySelect = "SELECT * FROM Officers WHERE Email = @Email AND Password = @Password";
                SqlCommand cmd = new SqlCommand(querySelect, conn);

                cmd.Parameters.AddWithValue("@Email", lc.Email);
                cmd.Parameters.AddWithValue("@Password", lc.Password);

                SqlDataReader read = cmd.ExecuteReader();

                if (read.HasRows)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }

    }
}
