﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Prison_Project.OfficerDbFC
{
    class OfficerDBClass
    {
        // Getters And Setters
        public int OfficerID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DOB { get; set; }
        public string Gender { get; set; }
        public string Country { get; set; }
        public string OfficerRank { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        static string strConnection = ConfigurationManager.ConnectionStrings["Prison_Project.Properties.Settings.PrisonDBConnectionString"].ConnectionString;
        //static string myconnstrng = ConfigurationManager.ConnectionStrings["connstrng"].ConnectionString;

        public DataTable SelectOfficers()
        {
            SqlConnection conn = new SqlConnection(strConnection);

            //Create an Object for DataTable
            DataTable DT = new DataTable();
            try
            {
                // Step 2: Write Sql Query
                string querySelAll = "SELECT * FROM Officers";
                // Create Command using "sql" and "conn"
                SqlCommand cmd = new SqlCommand(querySelAll, conn);
                // Create SqlDataAdapter using cmd
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                // Open connection
                conn.Open();
                // Fill our dt with our adapter.
                adapter.Fill(DT);
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return DT;
        }

        public bool CreateOfficer(OfficerDBClass odbc)
        {
            // Creating a default return type and setting its value to false
            bool isSuccess = false;

            // Step 1: Database Connection
            SqlConnection conn = new SqlConnection(strConnection);

            try
            {
                // Step 2: Write Sql Query to insert data
                string queryInsert = "INSERT INTO Officers (FirstName, LastName, DOB, Gender, Country, OfficerRank, Email, Password) VALUES (@FirstName, @LastName, @DOB, @Gender, @Country, @OfficerRank, @Email, @Password)";

                // Create cmd using "sql" and "conn"
                SqlCommand cmd = new SqlCommand(queryInsert, conn);

                // Create Parameters to add data
                cmd.Parameters.AddWithValue("@FirstName", odbc.FirstName);
                cmd.Parameters.AddWithValue("@LastName", odbc.LastName);
                cmd.Parameters.AddWithValue("@DOB", odbc.DOB);
                cmd.Parameters.AddWithValue("@Gender", odbc.Gender);
                cmd.Parameters.AddWithValue("@Country", odbc.Country);
                cmd.Parameters.AddWithValue("@OfficerRank", odbc.OfficerRank);
                cmd.Parameters.AddWithValue("@Email", odbc.Email);
                cmd.Parameters.AddWithValue("@Password", odbc.Password);

                // Open connection
                conn.Open();

                // Run the Query
                int rows = cmd.ExecuteNonQuery();

                // If the query runs successfully then the value "rows" will be greater then zero else it will be zero
                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }

        public bool UpdateOfficer(OfficerDBClass odbc)
        {
            SqlConnection conn = new SqlConnection(strConnection);

            bool isSuccess = false;

            try
            {
                string queryUpdate = "UPDATE Officers SET FirstName = @FirstName, LastName = @LastName, DOB = @DOB, Gender = @Gender, Country = @Country, OfficerRank = @OfficerRank, Email = @Email, Password = @Password WHERE OfficerID = @OfficerID";
                SqlCommand cmd = new SqlCommand(queryUpdate, conn);

                cmd.Parameters.Add("@FirstName", odbc.FirstName);
                cmd.Parameters.Add("@LastName", odbc.LastName);
                cmd.Parameters.Add("@DOB", odbc.DOB);
                cmd.Parameters.Add("@Gender", odbc.Gender);
                cmd.Parameters.Add("@Country", odbc.Country);
                cmd.Parameters.Add("@OfficerRank", odbc.OfficerRank);
                cmd.Parameters.Add("@Email", odbc.Email);
                cmd.Parameters.Add("@Password", odbc.Password);
                cmd.Parameters.Add("@OfficerID", odbc.OfficerID);

                conn.Open();

                // If the query runs successfully then the value "rows" will be greater then zero else it will be zero
                if (cmd.ExecuteNonQuery() > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }

        public bool DeleteOfficers(OfficerDBClass odbc)
        {
            // Creating a default return type and setting its value to false
            bool isSuccess = false;
            // Step 1: Database Connection
            SqlConnection conn = new SqlConnection(strConnection);
            try
            {
                // Step 2: Write Sql Query to Delete data in DB
                string queryDelete = "DELETE FROM Officers WHERE OfficerID = @OfficerID ";

                // Create Command using "sql" and "conn"
                SqlCommand cmd = new SqlCommand(queryDelete, conn);

                // Create Parameter to delete data
                cmd.Parameters.Add("@OfficerID", odbc.OfficerID);


                // Open connection
                conn.Open();

                // If the query runs successfully then the value "rows" will be greater then zero else it will be zero
                if (cmd.ExecuteNonQuery() > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }
    }
}
