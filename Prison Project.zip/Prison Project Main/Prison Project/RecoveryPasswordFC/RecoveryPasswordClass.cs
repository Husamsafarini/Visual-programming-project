﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Prison_Project.RecoveryPasswordFC
{
    class RecoveryPasswordClass
    {
        public string Email { get; set; }
        public string Password { get; set; }

        static string strConnection = ConfigurationManager.ConnectionStrings["Prison_Project.Properties.Settings.PrisonDBConnectionString"].ConnectionString;
        public bool ForgetPassword(RecoveryPasswordClass rpc)
        {
            SqlConnection conn = new SqlConnection(strConnection);

            // Creating a default return type and setting its value to false
            bool isSuccess = false;

            try
            {
                conn.Open();
                string querySelect = "SELECT Email FROM Officers WHERE Email = @Email";
                SqlCommand cmd = new SqlCommand(querySelect, conn);

                cmd.Parameters.AddWithValue("@Email", rpc.Email);
                string emailAddrerss = (string)cmd.ExecuteScalar();

                if (rpc.Email == emailAddrerss)
                {
                    // Update the password in the database
                    string queryUpdate = "UPDATE Officers SET Password = @Password WHERE Email = @Email";
                    cmd.CommandText = queryUpdate;
                    cmd.Parameters.AddWithValue("@Password", rpc.Password);
                    cmd.ExecuteNonQuery();

                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }

            return isSuccess;
        }
    }
}
